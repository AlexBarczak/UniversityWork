
public class EmptyStackException extends Exception {

	public EmptyStackException() {
		
	}
}
